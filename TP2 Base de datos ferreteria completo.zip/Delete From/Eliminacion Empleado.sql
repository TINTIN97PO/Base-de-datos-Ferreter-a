DELETE FROM Empleado;
DELETE FROM Empleado_ventas;


SELECT * FROM Empleado_ventas;
SELECT * FROM Empleado;