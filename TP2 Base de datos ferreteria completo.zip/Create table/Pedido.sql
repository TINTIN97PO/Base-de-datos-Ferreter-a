CREATE TABLE Pedido (
Numero_Pedido INT,
ID_Cliente INT,
Nombre_Cliente VARCHAR(40),
Fecha_Compra DATETIME,
FOREIGN KEY (ID_Cliente) REFERENCES Cliente(ID_Cliente)
);