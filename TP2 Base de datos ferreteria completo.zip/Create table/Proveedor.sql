CREATE TABLE Proveedor(
ID_Proveedor INT,
Nombre VARCHAR(20),
Apellido VARCHAR(20),
Telefono INT
);