CREATE TABLE Producto (
ID_Producto INT,
Nombre_Producto VARCHAR(30),
Precio DECIMAL(10,2),
Stock INT
);