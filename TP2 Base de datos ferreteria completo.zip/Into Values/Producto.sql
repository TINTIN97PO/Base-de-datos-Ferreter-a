INSERT INTO Producto (ID_Producto, Nombre_Producto, Precio, Stock)
VALUES
    (010, 'Martillo', 2020.25, 15),
    (011, 'Destornillador', 3524.00, 10),
    (012, 'Tuerca', 690.50, 36),
    (013, 'Caño de acero', 7850.50, 12);