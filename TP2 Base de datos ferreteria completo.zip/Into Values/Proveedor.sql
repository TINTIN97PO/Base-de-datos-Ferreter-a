INSERT INTO Proveedor (ID_Proveedor, Nombre, Apellido, Telefono )
VALUES
    (01, 'Felipe' ,'Gusman', 254 1445 96),
    (02, 'Agustina' , 'Alvarez', 458 9632 96),
    (03, 'Cristina' , 'Silva', 458 3215 96),
    (04, 'Facundo' , 'Garcia', 874 2564 22);
