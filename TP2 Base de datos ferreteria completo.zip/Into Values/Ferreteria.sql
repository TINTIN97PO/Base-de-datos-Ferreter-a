INSERT INTO Ferreteria (Cantidad_Empleados, Clientes, Productos, Proveedores)
VALUES
    (4, 10 , 653, 4);