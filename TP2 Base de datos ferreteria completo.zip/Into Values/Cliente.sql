INSERT INTO Cliente (ID_Cliente, Nombre, Apellido, telefono)
VALUES
    (001, 'Bruno' , 'Arizu', 425 1445 96),
    (002, 'Ludmila' , 'Fernandez', 424 2548 97),
    (003, 'Lucia' , 'Garcia', 965 8584 12),
    (004, 'Laura' , 'Jimenez', 655 6547 41),
    (005, 'Claudia' , 'Diaz', 494 6325 44),
    (006, 'Liliana' , 'Martinez', 455 8748 80),
    (007, 'Ricardo' , 'Gomez', 365 7477 93),
    (008, 'Julio' , 'Sanchez', 501 1323 45),
    (009, 'Alejandro' , 'Romero', 333 6528 01),
    (0010, 'Carina', 'Torres', 436 7745 07);
