INSERT INTO Empleado (ID_Empleado, Nombre, Apellido, Salario, Años_Trabajados)
VALUES
    (001, "Lucio", "Lopez", 150000, 3),
    (002, "Lucas", "Perez", 140000, 2),
    (003, "Agostina","Gomez", 160000, 4),
    (004, "Andres", "Gimenez", 110000, 1);