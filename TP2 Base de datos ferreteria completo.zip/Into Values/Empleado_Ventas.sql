INSERT INTO Empleado_Ventas(ID_Empleado, Nombre, Apellido )
VALUES
    (001, "Lucio", "Lopez" ),
    (002, "Lucas", "Perez"),
    (004, "Andres","Gimenez");