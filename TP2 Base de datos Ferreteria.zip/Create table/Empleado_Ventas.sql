CREATE TABLE Empleado_Ventas{
ID_Empleado INT,
Nombre VARCHAR(20),
Apellido VARCHAR(20)
FOREIGN KEY (ID_Empleado) REFERENCES Empleado(ID_Empleado)
};