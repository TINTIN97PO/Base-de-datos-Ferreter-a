CREATE TABLE Ferreteria{
Cantidad_Empleados INT,
Clientes INT,
Productos INT,
Proveedores INT
};