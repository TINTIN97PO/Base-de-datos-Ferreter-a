CREATE TABLE Empleado{
 ID_Empleado INT PRIMARY KEY,
 Nombre VARCHAR(20),
 Apellido VARCHAR(20),
 Salario INT,
 Años_Trabajados INT
};