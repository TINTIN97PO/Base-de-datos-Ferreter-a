CREATE TABLE Cliente{
ID_	Cliente INT PRIMARY KEY,
Nombre VARCHAR(20),
Apellido VARCHAR(20),
Telefono INT
};