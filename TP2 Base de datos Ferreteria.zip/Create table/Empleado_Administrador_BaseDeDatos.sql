CREATE TABLE Empleado_Administrador_BaseDeDatos{
Nombre VARCHAR(20),
Apellido VARCHAR(20)
};