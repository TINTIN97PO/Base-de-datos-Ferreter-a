DELETE FROM Cliente;
DELETE FROM Pedido;


SELECT * FROM Pedido;
SELECT * FROM Cliente;
