SELECT
E.ID_Empleado AS 'Identificacion Empleado',
EV.Nombre  AS 'Nombre',
EV.Apellido  AS 'Apellido',
E.Salario AS 'Sueldo',
E.Años_Trabajados AS 'Años Trabajados'

FROM
   Empleado E,
   Empleado_ventas EV,
  

WHERE
  E.ID_Empleado = EV.ID_Empleado;