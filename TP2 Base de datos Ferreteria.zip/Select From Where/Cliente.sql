SELECT
C.ID_Cliente AS 'ID Cliente',
C.Nombre AS 'Nombre',
C.Apellido AS 'Apellido',
C.Telefono AS 'Telefono',
P.Numero_Pedido AS 'Numero de Pedido',
P.Nombre_Cliente AS 'Nombre cliente',
P.Fecha_Compra AS 'Fecha de compra'


FROM

Cliente C,
Pedido P

WHERE

C.ID_Cliente = P.ID_Cliente;