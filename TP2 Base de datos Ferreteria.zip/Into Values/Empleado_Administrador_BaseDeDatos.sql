INSERT INTO Empleado_Administrador_BaseDeDatos (Nombre, Apellido )
VALUES
    ("Agostina","Gomez");