INSERT INTO Pedido (Numero_Pedido, ID_Cliente, Nombre_Cliente, Fecha_Compra)
VALUES
    (0011, 0001 , 'Bruno Arizu','2023-08-14 12:41');
    (0012, 0002 , 'Ludmila Fernandez','2023-08-18 13:52');
    (0013, 0003 , 'Lucia Garcia', '2023-09-01 14:55');
    (0014, 0004 , 'Laura Jimenez', '2023-11-02 15:24');
    (0015, 0005 , 'Claudia Diaz', '2023-11-13 17:22');
    (0016, 0006 , 'Liliana Martinez', '2023-11-14 17:42');
    (0017, 0007 , 'Ricardo Gomez', '2023-11-16 18:30');
    (0018, 0008 , 'Julio Sanchez', '2023-12-14 18:55');
    (0019, 0009 , 'Alejandro Romero', '2023-12-17 19:20');
    (0020, 00010 , 'Carina Torres', '2023-12-22 19:55');
    